import java.sql.SQLException;

public interface Cart {
    public static void addBookToCart()throws SQLException {

    }
    public static void deleteBookFromCart()throws SQLException {

    }
    public static void displayBookFromCart()throws SQLException{

    }
    public static void CheckUserInList()throws SQLException{

    }
}
