import java.sql.SQLException;

public interface Book {
    public static void insertBook()throws SQLException{

    }
    public static void deleteBook()throws SQLException{

    }
    public static void updateBook()throws SQLException{

    }
    public static void displayBook()throws SQLException {

    }
}

