import java.sql.*;
import java.util.Scanner;

public class Main implements User,Book,Cart {
    static Scanner ip = new Scanner(System.in);
    private static Connection con;
    private static Statement stm;

    public static void main(String[] args) throws SQLException {

        try {
            String addr = "jdbc:mysql://localhost:3306/bookstore";
            String username = "root";
            String password = "root";
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("Connected to my sql!!!");
            con = DriverManager.getConnection(addr, username, password);
            stm = con.createStatement();
            Options obj=new Options();
            obj.chooseOption();
        } catch (ClassNotFoundException exe) {
        } catch (SQLException exe) {
        }
    }

    public static void insertBook() throws SQLException {
        System.out.println("PLEASE ENTER BOOK NAME");
        String bookname = ip.next();
        System.out.println("PLEASE ENTER THE PRICE");
        Float price = ip.nextFloat();
        System.out.println("PLEASE ENTER THE NUMBER COPIES");
        int num_of_copies = ip.nextInt();
        System.out.println("PLEASE ENTER THE AUTHOR NAME");
        String author = ip.next();
        System.out.println("PLEASE ENTER YEAR OF PUBLISH");
        int YOP = ip.nextInt();
        String sql11 = "insert into book values(?,?,?,?,?)";
        PreparedStatement pstm = con.prepareStatement(sql11);
        pstm.setString(1, bookname);
        pstm.setFloat(2, price);
        pstm.setInt(3, num_of_copies);
        pstm.setString(4, author);
        pstm.setInt(5, YOP);
        int status11 = pstm.executeUpdate();
        if (status11 == 0) {
            System.out.println("PLEASE ENTER VALID BOOK NAME");
        } else {
            System.out.println("BOOK DETAILS ARE INSERTED");
        }
    }

    public static void deleteBook() throws SQLException {
        System.out.println("PLEASE ENTER BOOKNAME WHICH YOU WANT TO DELETE");
        String bookname = ip.next();
        String sql12 = "delete from book where bookname='"+ bookname + "'";
        int status12 = stm.executeUpdate(sql12);
        if (status12 == 0) {
            System.out.println("PLEASE ENTER VALID BOOK NAME");
        } else {
            System.out.println("BOOK DETAILS ARE DELETED");
        }
    }

    public static void updateBook() throws SQLException {
        System.out.println("PLEASE ENTER BOOK NAME");
        String bookname = ip.next();
        System.out.println("PLEASE ENTER THE CURRENT AUTHOR NAME ");
        String current_name = ip.next();
        System.out.println("PLEASE ENTER THE AUTHOR NAME WHICH YOU WANT TO UPDATE");
        String pri_name = ip.next();
        String sql13 = "update book set author=? where author=? and bookname='" + bookname + "'";
        PreparedStatement pstm = con.prepareStatement(sql13);
        pstm.setString(1, pri_name);
        pstm.setString(2, current_name);
        int status = pstm.executeUpdate();
        if (status == 0) {
            System.out.println("PLEASE ENTER CORRECT BOOKNAME");
        } else {
            System.out.println("BOOK DETAILS ARE UPDATED SUCCESFULLY");
        }
    }

    public static void displayBook() throws SQLException {
        //System.out.println("PLEASE ENTER THE BOOKNAME");
        //String bookname = ip.next();
        String sql13 = "select * from book ";
        ResultSet res = stm.executeQuery(sql13);
        while (res.next()) {
            System.out.println("Bookname :" + res.getString(1) + "\tPrice :" + res.getFloat(2) + "\tCopies :" + res.getInt(3) + "\tAuthor :" + res.getString(4) + "\tYop:" + res.getInt(5));
        }
    }

    public static void addUser() throws SQLException {
        System.out.println("PLEASE ENTER USER ID");
        int userid = ip.nextInt();
        System.out.println("PLEASE ENTER USER NAME");
        String username = ip.next();
        System.out.println("PLEASE ENTER PASSWORD");
        String password = ip.next();
        System.out.println("ENTER YOUR PLACE");
        String place = ip.next();
        String sql21 = "insert into user values(?,?,?,?)";
        PreparedStatement pstm = con.prepareStatement(sql21);
        pstm.setInt(1, userid);
        pstm.setString(2, username);
        pstm.setString(3, password);
        pstm.setString(4, place);
        int status21 = pstm.executeUpdate();
        if (status21 == 0) {
            System.out.println("PLEASE ENTER VALID USER ID");
        } else {
            System.out.println("USER DETAILS ARE INSERTED");
        }
    }

    public static void deleteUser() throws SQLException {
        System.out.println("PLEASE ENTER USER ID TO DELETE THE USER");
        int userid = ip.nextInt();
        String sql22 = "delete from user where userid=" + userid + "";
        int status22 = stm.executeUpdate(sql22);
        if (status22 == 0) {
            System.out.println("PLEASE ENTER VALID USER ID");
        } else {
            System.out.println("USER DETAILS ARE DELETED");
        }
    }

    public static void displayUser() throws SQLException {
        //System.out.println("PLEASE ENTER USER ID");
        //int userid = ip.nextInt();
        String sql23 = "select * from user";
        ResultSet res = stm.executeQuery(sql23);
        while (res.next()) {
            System.out.println("UserID:" + res.getInt(1) + "\tUserName :" + res.getString(2) + "\tPassword :" + res.getString(3) + "\tPlace :" + res.getString(4));
        }
    }

    public static void updateUser() throws SQLException {
        System.out.println("ENTER USER ID TO UPDATE THE USER");
        int userid = ip.nextInt();
        System.out.println("ENTER THE CURRENT USER NAME");
        String current_name = ip.next();
        System.out.println("ENTER THE NAME WHICH YOU WANT TO UPDATE AS USERNAME");
        String pri_name = ip.next();
        String sql24 = "update user set username=? where username=? and userid=" + userid + "";
        PreparedStatement pstm = con.prepareStatement(sql24);
        pstm.setString(1, pri_name);
        pstm.setString(2, current_name);
        int status = pstm.executeUpdate();
        if (status == 0) {
            System.out.println("PLEASE ENTER USERID WHICH IS PRESENT IN THE USER TABLE");
        } else {
            System.out.println("USER DETAILS ARE UPDATED");
        }
    }
    public static void addBookToCart() throws SQLException {
        int num_of_copies = 0;
        System.out.println("PLEASE ENTER USER ID");
        int userid = ip.nextInt();
        System.out.println("PLEASE ENTER BOOK NAME WHICH YOU WANT TO ADD TO THE CART");
        String bookname = ip.next();
        System.out.println("ENTER THE NUMBER COPIES TO ADDED ON TO THE CART");
        int addCopies = ip.nextInt();
        String sql1 = "select num_of_copies from book where bookname='" + bookname + "'";
        ResultSet resnum_of_copies = stm.executeQuery(sql1);
        while (resnum_of_copies.next()) {
            num_of_copies = resnum_of_copies.getInt(1);
        }
        if (num_of_copies>= addCopies) {
            String sql2 = "insert into cart values(" + userid + ",'" + bookname + "'," + addCopies + ")";
            int status = stm.executeUpdate(sql2);
            num_of_copies=num_of_copies-addCopies;
            if (status == 0) {
                System.out.println("PLEASE ENTER DIFFERNET OOK NAME");
            }
            else {
                System.out.println("YOUR CART IS UPDATED");
            }
            if (status > 0) {
                if (num_of_copies > 0) {
                    String decrement_num_of_copies = "update book set num_of_copies=" + num_of_copies + " where bookName='" + bookname + "'";
                    stm.executeUpdate(decrement_num_of_copies);
                } else {
                    String sql3 = "delete from book where bookname='" + bookname + "'";
                    stm.executeUpdate(sql3);
                }
            }
        }
        else {
            System.out.println("BOOK IS NOT PRESENT IN THE TABLE");
        }
    }

    public static void displayBookFromCart() throws SQLException {
        System.out.println("PLEASE ENTER USER ID TO RETRIVE THE DATA");
        int userid=ip.nextInt();
        String sql="select bookname,num_of_copies from cart where userid="+userid+"";
        ResultSet res=stm.executeQuery(sql);
        while (res.next()){
            System.out.println(" Num_of_copies: "+res.getInt(2)+"Book Name: "+res.getString(1));
        }
    }

    public static void deleteBookFromCart() throws SQLException {
        int num_of_copies=0;
        int  bookCopies=0;
        System.out.println("PLEASE ENTER USER ID");
        int userid=ip.nextInt();
        System.out.println("PLEASE ENTER BOOK NAME WHICH YOU WISH TO DELETE");
        String bookname=ip.next();
        String sql="select num_of_copies from cart where userid="+userid+" and bookname='"+bookname+"'";
        ResultSet res=stm.executeQuery(sql);
        while (res.next()){
            num_of_copies=num_of_copies+res.getInt(1);
        }
        String sql1="delete from cart where userid="+userid+" and bookname='"+bookname+"'";
        int status=stm.executeUpdate(sql1);
        if(status>0){
            System.out.println("Deletion done in cart");
            String checkCopiesInBook="select num_of_copies from book where bookname='"+bookname+"'";
            ResultSet resCheck=stm.executeQuery(checkCopiesInBook);
            while (resCheck.next()){
                bookCopies=resCheck.getInt(1);
            }
            bookCopies=bookCopies+num_of_copies;

            String sql2="update book set num_of_copies="+bookCopies+" where bookName='"+bookname+"'";
            stm.executeUpdate(sql2);
        }
        else {
            System.out.println("Book not present in cart");
        }
    }
    public static int  CheckUserInList() throws SQLException {
        int count=0;
        System.out.println("PLEASE ENTER USER ID TO CONFIRM THE USER :");
        int userid=ip.nextInt();
        String sql51="select userName from user where userid="+userid+"";
        ResultSet res=stm.executeQuery(sql51);
        while (res.next()){
            count++;
        }
        if(count>=1){
            System.out.println("THANK YOU USER IS VALIDATED");
        }
        return count;
    }

}

