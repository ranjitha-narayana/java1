import java.sql.SQLException;
import java.util.Scanner;

public class Options {
    public static void chooseOption() throws SQLException {
        Scanner ip=new Scanner(System.in);
        while (true) {
            System.out.println("please chose your option to perform operation");
            System.out.println("Main Menu");
            System.out.println("1.Book_operation\n2.User_operation\n3.Cart_operation\n4.Exit");
            int option = ip.nextInt();
            switch (option) {
                case 1:
                    Book_Operations();
                    break;
                case 2:
                    User_Operations();
                    break;
                case 3:
                    Cart_Operations();
                    break;
                case 4:
                    System.exit(0);
                    break;
                default:
                    System.out.println("choose the correct option");
            }
        }
    }
    public static void Book_Operations() throws SQLException {
        Scanner ip = new Scanner(System.in);
        while (true) {
            System.out.println("please chose your option to perform operation of books");
            System.out.println("1.Inserting a Book\n2.Deleting a Book\n3.Displaying\n4.Updating\n5.Exit");
            int option1 = ip.nextInt();
            switch (option1) {
                case 1:
                    Main.insertBook();
                    break;
                case 2:
                    Main.deleteBook();
                    break;
                case 3:
                    Main.displayBook();
                    break;
                case 4:
                    Main.updateBook();
                    break;
                case 5:
                    chooseOption();
                    break;
                default:
                    System.out.println("CHOOSE CORRECT OPTION");
            }
        }
    }
    public static void User_Operations() throws SQLException {
        Scanner ip = new Scanner(System.in);
        while (true) {
            System.out.println("please chose your option to perform operation on user");
            System.out.println("1.AddUser\n2.deleteUser \n3.displayUser\n4.UpdateUser\n5.Exit");
            int option = ip.nextInt();
            switch (option) {
                case 1:
                    Main.addUser();
                    break;
                case 2:
                    Main.deleteUser();
                    break;
                case 3:
                    Main.displayUser();
                    break;
                case 4:
                    Main.updateUser();
                    break;
                case 5:
                    chooseOption();
                    break;
                default:
                    System.out.println("choose the correct option");
            }
        }
    }

    public static void Cart_Operations()throws SQLException {
        while (true) {
            Scanner ip=new Scanner(System.in);
            System.out.println("please chose your option to perform operation of cart");
            System.out.println("1.Add book to cart\n2.Deleting a Book\n3.Displaying\n4.Validating user\n5.Exit");
            int option = ip.nextInt();
            switch (option) {
                case 1:
                    Main.addBookToCart();
                    break;
                case 2:
                    Main.deleteBookFromCart();
                    break;
                case 3:
                    Main.displayBookFromCart();
                    break;
                case 4:
                    int count = Main.CheckUserInList();
                    if (count >= 1) {
                        Cart_Operations();
                    } else {
                        System.out.println("Enter user id which is present in database");
                    }
                    break;
                case 5:
                    chooseOption();
                    break;
                default:
                    System.out.println("choose the correct option");
            }
        }
    }
}

