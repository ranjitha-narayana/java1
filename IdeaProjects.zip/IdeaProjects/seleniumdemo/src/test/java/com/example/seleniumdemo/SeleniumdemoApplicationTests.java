package com.example.seleniumdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeleniumdemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
