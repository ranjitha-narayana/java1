import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;

class ContactManagerTest {
    private  static ContactManager contactmanager;
    @BeforeAll
    public  static void setupAll(){
        System.out.println("Instantiating contact manager before the test execution");

    }



    @BeforeEach
    public  void setup(){
        System.out.println("Instantiating contact manager");
        contactmanager=new ContactManager();

    }
    @Test
    @DisplayName("should create contact")
    public void shouldCreateContact() {
        ContactManager contactmanager = new ContactManager();
       contactmanager.addContact("Ranjitha", "A", "0234567834");
        Assertions.assertFalse(contactmanager.getAllContacts().isEmpty());
        Assertions.assertEquals(1, contactmanager.getAllContacts().size());

    }

    @Test
    @DisplayName("SHOULD NOT CREATE CONTACT WHEN FIRST NAME IS NULL")
    public void throwErrorWhenFirstNameIsNull() {
        ContactManager contactManager = new ContactManager();
        Assertions.assertThrows(RuntimeException.class, () -> {
            contactManager.addContact(null, "A", "0234567834");
        });
    }

    @Test
    @DisplayName("SHOULD NOT CREATE CONTACT WHEN LAST NAME IS NULL")
    public void throwErrorWhenLastNameIsNull() {
        ContactManager contactManager = new ContactManager();
        Assertions.assertThrows(RuntimeException.class, () -> {
            contactManager.addContact("ranjitha", null, "0234567834");
        });
    }

    @Test
    @DisplayName("SHOULD NOT CREATE CONTACT WHEN phone number IS NULL")
    public void throwErrorWhenPhoneNumberIsNull() {
        ContactManager contactManager = new ContactManager();
        Assertions.assertThrows(RuntimeException.class, () -> {
            contactManager.addContact("ranjitha", "A", null);
        });
    }

@AfterEach
public void finish(){
    System.out.println("should execute after each test");

}
@AfterAll
public static void finishAll(){
    System.out.println("should execute at the end of the test");
    }
}


