public interface studentInterface {
        public void insertStudent();
        public void removeStudent();
        public void displayStudents();
        public void exit();
    }

