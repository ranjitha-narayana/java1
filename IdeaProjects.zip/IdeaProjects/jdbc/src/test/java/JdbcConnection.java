import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class JdbcConnection {
    public static void main(String[] args) throws SQLException {
        Connection con=null;
        Statement st;
        try {
            String addr = "jdbc:mysql://localhost:3306/jdbc";
            String username = "root";
            String password = "root";
            Class.forName("com.mysql.cj.jdbc.Driver");
            con= DriverManager.getConnection(addr,username,password);
            st=con.createStatement();
            System.out.println("connection is established");

        } catch (ClassNotFoundException e) {
            System.out.println(e.getException());

        } catch (SQLException e) {
            System.out.println(e.getNextException());
        }
        finally{
            con.close();
        }
    }
}
