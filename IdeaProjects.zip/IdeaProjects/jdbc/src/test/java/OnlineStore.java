import java.sql.Connection;
import java.sql.Statement;
import java.util.Scanner;

class Store {

        public void Options() {

            OnlineWeb dm = new OnlineWeb();
            OnlineUser ou = new OnlineUser();
            CartDemo1 cd1 = new CartDemo1();
            Scanner sc = new Scanner(System.in);
            while (true) {

                System.out.println("1:BookTABLEoptions,2:UserOptions,3:CartOptions,4:exit");
                System.out.println("enter the option");
                int option = sc.nextInt();
                switch (option) {
                    case 1:
                        System.out.println("these are  the Book operations");
                        dm.Option();
                        break;
                    case 2:
                        System.out.println("these are  the user operations");
                        ou.Option();
                        break;
                    case 3:
                        System.out.println("these are  the cart operations");
                        cd1.Option();
                        break;
                    case 4:
                        System.exit(0);
                    default:
                        System.out.println("enter option correctly");
                }

            }

        }
    }
public class OnlineStore {
        public static void main(String args[]) {
           Store os = new Store();
           os.Options();
        }
    }







