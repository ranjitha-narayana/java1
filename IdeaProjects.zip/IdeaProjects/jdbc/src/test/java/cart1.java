


import java.sql.*;
import java.util.Scanner;

class CartDemo1 {
    Connection con = null;
    Statement stm;
    String addr = "jdbc:mysql://localhost:3306/eweb";
    String username = "root";
    String password = "root";
    Scanner sc = new Scanner(System.in);

    public void Option() {
        while (true) {
            Store os=new Store();
            System.out.println("1:addBookToCart,2:deleteFromCart,3:DisplayBookFromCart,4:CheckUserInList,5:exit");
            System.out.println("enter the option");
            int option = sc.nextInt();
            switch (option) {
                case 1:
                    addBookToCart();
                    break;
                case 2:
                    deleteFromCart();
                    break;
                case 3:
                    displayFromCart();
                    break;
                case 4:
                    os.Options();
                    break;

                default:
                    System.out.println("enter option correctly");
            }

        }

    }


    public void addBookToCart() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(addr, username, password);
            System.out.println("Connected to DB ...");
            stm = con.createStatement();

            PreparedStatement pstm = con.prepareStatement("SELECT u.userid,c.bookname FROM user u,cart c WHERE u.userid = ? and c.bookname=?");
            System.out.println("enter userid to know the details");
            pstm.setInt(1, sc.nextInt());
            System.out.println("enter the bookname");
            pstm.setString(2, sc.next());
            ResultSet rs = pstm.executeQuery();
            System.out.println("---------- DB----------");
            if (rs.next()) {

                System.out.println("userid and bookname is present");
                System.out.println("update to cart ");
                PreparedStatement pstm3 = con.prepareStatement("update cart set number_of_copies=number_of_copies+1 where bookname=?");
                System.out.println("enter bookname");
                pstm3.setString(1, sc.next());
                pstm3.executeUpdate();
            } else {

                System.out.println("bookname is not present add");
                PreparedStatement pstm1 = con.prepareStatement("insert into cart values(?,?,?)");
                System.out.println("enter bookname");
                pstm1.setString(1, sc.next());
                System.out.println("enter userid");
                pstm1.setInt(2, sc.nextInt());      //System.in
                System.out.println("enter number_of_copies");
                pstm1.setInt(3, sc.nextInt());

                int i = pstm1.executeUpdate();
                System.out.println(i + " rows affected");
            }
        } catch (ClassNotFoundException e) {
            System.out.println(e);
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    public void deleteFromCart() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(addr, username, password);
            System.out.println("Connected to DB ...");
            stm = con.createStatement();

            PreparedStatement pstm = con.prepareStatement("select number_of_copies from cart where bookname=? and number_of_copies>1");
            System.out.println("enter the bookname present in cart");
            pstm.setString(1, sc.next());
            ResultSet rs = pstm.executeQuery();
            if (rs.next()) {
                System.out.println("number of copies is greater than 1");
                System.out.println("delete one copy");
                PreparedStatement pstm1 = con.prepareStatement("update cart set number_of_copies=number_of_copies-1");
                pstm1.executeUpdate();
            } else {
                System.out.println("number of copies is only one delete");
                PreparedStatement pstm2 = con.prepareStatement("delete bookname from cart where number_of_copies<=1");
                pstm2.executeUpdate();
            }

        } catch (ClassNotFoundException e) {
            System.out.println(e);
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    public void displayFromCart() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(addr, username, password);
            System.out.println("Connected to DB ...");
            stm = con.createStatement();

            PreparedStatement pstm = con.prepareStatement("select bookname from cart");
            ResultSet rs = pstm.executeQuery();
            while(rs.next()) {
                System.out.println("Bookname are:\n" +rs.getString("bookname"));

            }
        } catch (ClassNotFoundException e) {
            System.out.println(e);
        } catch (SQLException e) {
            System.out.println(e);
        }

    }
}
public class cart1 {
    public static void main(String[] args) {
        CartDemo1 cd1 = new CartDemo1();
        cd1.Option();
    }
}

