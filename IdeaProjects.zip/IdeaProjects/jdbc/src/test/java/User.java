import java.sql.*;
import java.util.Scanner;

class OnlineUser {
    Connection con=null;
    Statement stm;
    String addr = "jdbc:mysql://localhost:3306/eweb";
    String username = "root";
    String password = "root";
    Scanner sc = new Scanner(System.in);

    public void Option() {
        while(true){
            Store os=new Store();
            System.out.println("1:adduser,2:removeuser,3:Display,4:updateuser,5:exit");
            System.out.println("enter the option");
            int option = sc.nextInt();
            switch (option) {
                case 1:
                    addUser();
                    break;
                case 2:
                    removeUser();
                    break;
                case 3:
                    displayUser();
                    break;
                case 4:
                    updateUser();
                    break;
                case 5:
                    os.Options();
                    break;
                default:
                    System.out.println("enter option correctly");
            }

        }

    }

    public void addUser() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(addr, username, password);
            System.out.println("Connection Established Successfully");
            stm = con.createStatement();
            PreparedStatement pstm = con.prepareStatement("INSERT INTO user VALUES(?,?,?,?)");
            System.out.println("enter userid"); pstm.setInt(1, sc.nextInt());             //take buffer reader or Scanner class
            System.out.println("enter username"); pstm.setString(2, sc.next());      //System.in
            System.out.println("enter PASSWORD"); pstm.setInt(3, sc.nextInt());
            System.out.println("enter PLACE");pstm.setString(4, sc.next());

            int i = pstm.executeUpdate();
            System.out.println(i + " rows affected");
        } catch (ClassNotFoundException e) {
            System.out.println(e);
            System.out.println("failed..");
        } catch (SQLException e) {
            System.out.println(e);
        }
    }



    public void removeUser () {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(addr, username, password);
            System.out.println("Connection Established Successfully");
            stm = con.createStatement();
            PreparedStatement pstm = con.prepareStatement("DELETE FROM user WHERE userid = ?");
            System.out.println("enter the userid to remove the details");
            pstm.setString(1, sc.next());
            int i = pstm.executeUpdate();
            System.out.println(i + " rows affected");
        } catch (ClassNotFoundException e) {
            System.out.println(e);
            System.out.println("failed..");
        } catch (SQLException e) {
            System.out.println(e);
        }
    }
    public void displayUser() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(addr, username, password);
            System.out.println("Connected to DB ...");
            stm = con.createStatement();
            PreparedStatement pstm = con.prepareStatement("SELECT * FROM user WHERE userid = ?");
            System.out.println("enter userid to know the details"); pstm.setInt(1, sc.nextInt());
            ResultSet rs = pstm.executeQuery();
            System.out.println("---------- DB----------");
            while (rs.next()) {
                System.out.println(rs.getInt("userid")+"   "+ rs.getString("username")+"   "+ rs.getInt("password")+"    " + rs.getString("place"));
            }
            System.out.println("rows affected"+rs);


        } catch (ClassNotFoundException e) {
            System.out.println(e);
        } catch (SQLException e) {
            System.out.println(e);
        }

    }
    public void updateUser(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(addr, username, password);
            System.out.println("Connected to DB ...");
            stm = con.createStatement();
            PreparedStatement pstm = con.prepareStatement("update user set username = ? where userid= ?");
            System.out.println("enter username that you want to update"); pstm.setString(1, sc.next());
            System.out.println("enter the userid");pstm.setInt(2,sc.nextInt());
            pstm.executeUpdate();
            System.out.println("---------- DB----------");

            System.out.println("rows affected"+pstm);

        } catch (ClassNotFoundException e) {
            System.out.println(e);
        } catch (SQLException e) {
            System.out.println(e);
        }

    }

}

public class User{
    public static void main(String[] args) {
        OnlineUser ou = new OnlineUser();
        ou.Option();
    }
}




