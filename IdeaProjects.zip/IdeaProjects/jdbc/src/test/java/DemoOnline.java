import java.sql.*;
import java.util.Scanner;

class OnlineWeb {
    Connection con=null;
    Statement stm;
    String addr = "jdbc:mysql://localhost:3306/eweb";
    String username = "root";
    String password = "root";
    Scanner sc = new Scanner(System.in);

    public void Option() {
        while(true){
            Store os=new Store();
            System.out.println("1:insert,2:remove,3:Display,4:update,5:exit");
            System.out.println("enter the option");
            int option = sc.nextInt();
            switch (option) {
                case 1:
                    insertBook();
                    break;
                case 2:
                    removeBook();
                    break;
                case 3:
                    displayBook();
                    break;
                case 4:
                    updateBook();
                    break;
                case 5:
                    os.Options();
                    break;
                default:
                    System.out.println("enter option correctly");
            }

        }

    }

    public void insertBook() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(addr, username, password);
            System.out.println("Connection Established Successfully");
            stm = con.createStatement();
            PreparedStatement pstm = con.prepareStatement("INSERT INTO Book VALUES(?,?,?,?,?)");
            System.out.println("enter bookname"); pstm.setString(1, sc.next());             //take buffer reader or Scanner class
            System.out.println("enter price"); pstm.setInt(2, sc.nextInt());      //System.in
            System.out.println("enter number of copies"); pstm.setInt(3, sc.nextInt());
            System.out.println("enter author");pstm.setString(4, sc.next());
            System.out.println("enter yearofpublish"); pstm.setInt(5, sc.nextInt());
            int i = pstm.executeUpdate();
            System.out.println(i + " rows affected");
        } catch (ClassNotFoundException e) {
            System.out.println(e);
            System.out.println("failed..");
        } catch (SQLException e) {
            System.out.println(e);
        }
    }



    public void removeBook () {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(addr, username, password);
            System.out.println("Connection Established Successfully");
            stm = con.createStatement();
            PreparedStatement pstm = con.prepareStatement("DELETE FROM Book WHERE bookname = ?");
            System.out.println("enter the bookname to remove the details");
            pstm.setString(1, sc.next());
            int i = pstm.executeUpdate();
            System.out.println(i + " rows affected");
        } catch (ClassNotFoundException e) {
            System.out.println(e);
            System.out.println("failed..");
        } catch (SQLException e) {
            System.out.println(e);
        }
    }
    public void displayBook() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(addr, username, password);
            System.out.println("Connected to DB ...");
            stm = con.createStatement();
            PreparedStatement pstm = con.prepareStatement("SELECT * FROM Book");
            ResultSet rs = pstm.executeQuery();
            System.out.println("---------- DB----------");
            while (rs.next()) {
                System.out.println(rs.getString("bookname")+"   "+ rs.getInt("price")+"   "+ rs.getInt("number_of_copies")+"    " + rs.getString("author")+"   " + rs.getInt("yearofpublish"));
            }
            System.out.println("rows affected"+rs);


        } catch (ClassNotFoundException e) {
            System.out.println(e);
        } catch (SQLException e) {
            System.out.println(e);
        }

    }
    public void updateBook(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(addr, username, password);
            System.out.println("Connected to DB ...");
            stm = con.createStatement();
            PreparedStatement pstm = con.prepareStatement("update Book set bookname = ? where bookname= ?");
            System.out.println("enter updationbookname"); pstm.setInt(1, sc.nextInt());
            System.out.println("enter the bookname which u want to update");pstm.setString(2,sc.next());
             pstm.executeUpdate();
            System.out.println("---------- DB----------");

            System.out.println("rows affected"+pstm);

        } catch (ClassNotFoundException e) {
            System.out.println(e);
        } catch (SQLException e) {
            System.out.println(e);
        }

    }

}

public class DemoOnline {
    public static void main(String[] args) {
        OnlineWeb ow = new OnlineWeb();
        ow.Option();
    }
}




