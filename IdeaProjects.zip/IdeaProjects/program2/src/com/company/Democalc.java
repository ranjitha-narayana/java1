package com.company;

import java.util.Scanner;

class arrays{
    static int n = 50;
    int[] array = new int[n];
    static int count;

    public void twoPair(){
        System.out.println("TWO PAIR ARRAYS");
        Scanner sc = new Scanner(System.in);
        System.out.println("enter size");
        int num = sc.nextInt();
        System.out.println("Enter the Array Elements");
        for(int i = 0; i<num; i++){
            array[i] = sc.nextInt();
        }
        for (int i = 0; i <=num; i++) {
            for (int j = i + 1; j<num; j++) {
                System.out.println(array[i] + "   " + array[j]);
                count++;

            }

        }
        System.out.println(count++);
        sc.close();

    }

    public void threePair(){
        System.out.println("Three PAIR ARRAYS");
        Scanner sc = new Scanner(System.in);
        System.out.println("enter size");
        int num = sc.nextInt();
        System.out.println("Enter the Array Elements ");
        for(int i = 0; i<num; i++){
            array[i] = sc.nextInt();
        }
        for (int i = 0; i <=num; i++) {
            for (int j = i + 1; j<num; j++) {
                for(int k = j + 1; k<num; k++){
                    System.out.println(array[i] + "  " + array[j]+"  "+ array[k]);
                    count++;
                }


            }

        }
        System.out.println(count++);
        sc.close();



    }

    public void fourPair(){
        System.out.println("four PAIR ARRAYS");
        Scanner sc = new Scanner(System.in);
        System.out.println("enter size");
        int num = sc.nextInt();
        System.out.println("Enter the Array Elements");
        for(int i = 0; i<num; i++){
            array[i] = sc.nextInt();
        }
        for (int i = 0; i <=num; i++) {
            for (int j = i + 1; j<num; j++) {
                for(int k = j + 1; k<num; k++){
                    for(int m = k+1; m<num; m++){
                        System.out.println(array[i] + "  " + array[j]+"  "+ array[k]+" "+array[m]);
                        count++;
                    }
                }


            }

        }
        System.out.println(count++);
        sc.close();



    }
    public void fivePair(){
        System.out.println("Five PAIR ARRAYS");
        Scanner sc = new Scanner(System.in);
        System.out.println("enter size");
        int num = sc.nextInt();
        System.out.println("Enter the Array Elements..");
        for(int i = 0; i<num; i++){
            array[i] = sc.nextInt();
        }
        for (int i = 0; i <=num; i++) {
            for (int j = i + 1; j<num; j++) {
                for(int k = j + 1; k<num; k++){
                    for(int m = k+1; m<num; m++){
                        for(int n=m+1; n<num; n++){
                            System.out.println(array[i] + "  " + array[j]+"  "+ array[k]+" "+array[m]+" "+array[n]);
                            count++;
                        }
                    }
                }


            }

        }
        System.out.println(count++);
        sc.close();



    }

}

public class Democalc {
    public static void main(String[] args) throws Exception{

        arrays a = new arrays();
        Scanner sc = new Scanner(System.in);
        while(true){
            System.out.println("Enter 1-twoPair, 2-threePair, 3-fourPair, 4-fivePair,5-Exit");
            int test =sc.nextInt();
            switch(test){
                case 1:
                    a.twoPair();
                    break;
                case 2:
                    a.threePair();
                    break;
                case 3:
                    a.fourPair();
                    break;
                case 4:
                    a.fivePair();
                    break;
                case 5:System.exit(0);
                default:System.out.println("Invalid input");

            }
        }

    }
}