package com.company;

public interface Toys extends AdvancedToy{
    public abstract void name();
    public abstract void Category();
    public abstract void price();


}
