package com.company;

import java.io.OutputStream;

public class DenoException {
    public static void main(String args[]) {
        int[] array = {1, 2, 3, 4, 5, 6, 7, 8, 9};
        int n = array.length;

        try {
            for (int i = 0; i <=n; i++) {
                for (int j =i; j<n; j++) {

                    System.out.println(+array[i] + "," + array[j]);
                }
            }
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("index 9 is out of bound for length 9" );
        }


    }
}
