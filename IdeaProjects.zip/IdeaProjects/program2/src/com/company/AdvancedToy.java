package com.company;

public interface AdvancedToy {
    public void color();
    public void company();
    public void offer();
}
