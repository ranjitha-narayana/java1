package com.company;

import java.util.Scanner;

public class Calculator {
    int num1;
    int num2;
    int result;
    int numbers;


    public void add() {
        Scanner numbers = new Scanner(System.in);
        System.out.println("enter the first number");
        num1 = numbers.nextInt();
        System.out.println("enter the second number");
        num2 = numbers.nextInt();
        result = num1 + num2;
        System.out.println("Addition is"+result);
    }

    public void sub() {
        Scanner numbers = new Scanner(System.in);
        System.out.println("enter the first number");
        num1 = numbers.nextInt();
        System.out.println("enter the second number");
        num2 = numbers.nextInt();
        result = num1 - num2;
        System.out.println("Subtraction is:" +result);

    }

    public void mult() {
        Scanner numbers = new Scanner(System.in);
        System.out.println("enter the first number");
        num1 = numbers.nextInt();
        System.out.println("enter the second number");
        num2 = numbers.nextInt();
        result = num1 * num2;
        System.out.println("Multiplication is:" +result);
    }

    public void div() {
        Scanner numbers = new Scanner(System.in);
        System.out.println("enter the first number");
        num1 = numbers.nextInt();
        System.out.println("enter the second number");
        num2 = numbers.nextInt();
        result = num1 / num2;
        System.out.println("Division is:" +result);
    }
}
 class Advancedcalc extends Calculator{
    public void checkNumber()
    {
        Scanner scan=new Scanner(System.in);
        int num1=scan.nextInt();
        if(num1%2==0) {
            System.out.println(" number is even");
        }
            else {
                System.out.println("number is odd");
            }

        }
        public void squareroot(){
        System.out.println("enter number to find its square root");
        Scanner number=new Scanner(System.in);
        int num=number.nextInt();
        int result=num*num;
        System.out.println("Square root of number  is:" +result);
        }
    }

    class  sample {

        public static void main(String args[]){
            Calculator obj = new Calculator();
            Advancedcalc obj1 = new Advancedcalc();
            int n=7;
            System.out.println("1:add,2:sub,3:mult,4:div,5:checkNumber,6:squareroot,7.exit");
            Scanner sc = new Scanner(System.in);
            for (int i = 0; i <n; i++) {
                int option = sc.nextInt();
                switch (option) {
                    case 1:
                        obj.add();
                        break;
                    case 2:
                        obj.sub();
                        break;
                    case 3:
                        obj.mult();
                        break;
                    case 4:
                        obj.div();
                        break;
                    case 5:
                        obj1.checkNumber();
                        break;
                    case 6:
                        obj1.squareroot();
                        break;
                    case 7:
                        System.exit(0);


                }
            }
        }

    }










