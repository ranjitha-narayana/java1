import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class studentTest {
    public int Square(int i){
        return i*i;
    }
    public int Sum(int a,int b){
        return a+b;
    }
    public int Sub(int a,int b){
        return a-b;
    }

}
