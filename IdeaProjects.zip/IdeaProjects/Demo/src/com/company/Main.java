package com.company;

import java.awt.*;

public class Main {

    public static void main(String args[]) {
	// write your code here
        int x,y;
        Point point1=new Point(x =2 ,y=3);
        Point point2=point1;
        System.out.println(point1);
    }
}
