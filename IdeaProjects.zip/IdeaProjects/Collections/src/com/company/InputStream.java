package com.company;

import java.io.FileInputStream;

public class InputStream {
    public static void main(String[] args){
        try{
            FileInputStream in =new FileInputStream("C:\\Users\\user425\\Desktop\\docs\\test.txt");
            int i=0;
            while((i=in.read())!=-1) {
                System.out.print((char) i);
            }
            in.close();
            }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
}
