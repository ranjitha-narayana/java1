package com.company;

import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;

public class OutputStream {
    public static void main(String[] args){
        try {
            FileOutputStream out = new FileOutputStream("C:\\Users\\user425\\Desktop\\docs\\test.txt");
            String s = "hello welcome";
            byte a[] = s.getBytes();
            out.write(a);
            out.close();
            System.out.println("successful");
        }
        catch(Exception e){
            System.out.println(e);
        }
    }
}
