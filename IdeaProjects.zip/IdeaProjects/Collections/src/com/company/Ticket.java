package com.company;

public interface Ticket {
    public void Booking();
    public void TicketDetails();
    public void Remove();
}
