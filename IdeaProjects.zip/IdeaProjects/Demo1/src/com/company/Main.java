package com.company;

import java.util.Arrays;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        // write your code here
        String[] names = new String[4];
        for (int i = 0; i < names.length; i++) {
            System.out.println("1:input,2:output,3.search,4.update,5.exit");
            Scanner sc = new Scanner(System.in);
            int option = sc.nextInt();
            switch (option) {
                case 1:
                    System.out.println("enter four name");
                    for (int j = 0; j < names.length; j++)
                        names[j] = sc.nextLine();
                    break;
                case 2:
                    System.out.println(Arrays.toString(names));
                    break;
                case 3:
                    System.out.println("enter the string you want to search");
                    String sr=sc.next();
                    for(int w=0 ;w<names.length;w++) {
                        if (names[w].equals(sr)) {
                            System.out.println("string is present");


                        }
                    }
                case 4:
                    System.out.println("enter the string to update");
                    String up=sc.next();
                    for(int s=0;s<names.length;s++){
                        if(names[s].equals(up)){
                            String updated=sc.next();
                            names[s]=updated;
                        }
                    }

            }
        }
    }
}
